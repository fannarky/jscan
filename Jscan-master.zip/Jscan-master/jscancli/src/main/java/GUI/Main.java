package GUI;

import Model.Computador;
import OSHI.PcInfo;
import OSHI.PcLeitura;
import org.json.JSONObject;
import javax.swing.*;
import java.util.Timer;
import java.util.TimerTask;
import Slack.Slack;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {
        Slack slack = new Slack();
        Thread alertaMemoria = new Thread() {
            @Override
            public void run() {
                
                //seta o computador na inicialização
                PcInfo pc = new PcInfo();
                
                Computador.setNmComputador(pc.getNomeDoComputador());
                Computador.setNmModeloSistema(pc.getModeloDoComputador());
                Computador.setNmProcessador(pc.getProcessador());
                Computador.setNmSistemaOperacional(pc.getSistemaOperacional());
                Computador.setVlArmazenamento(pc.getArmazenamentoTotal());
                Computador.setVlMemoriaRam(pc.getRam());

                PcLeitura leitura = new PcLeitura();
                Timer timer = new Timer();

                //timer de monitoramento
                timer.scheduleAtFixedRate(new TimerTask(){
                    @Override
                    public void run(){
                        
                        
                        if(leitura.alertaMemoria()){
                            String msgMemoria = "MEMÓRIA PRINCIPAL ACIMA DO ACEITÁVEL!";
                            JOptionPane.showMessageDialog(null,msgMemoria);
                            if(Slack.getURL() != null){
                                JSONObject message = new JSONObject();
                                message.put("text", msgMemoria);
                                try {
                                    slack.insertMessage(message);
                                } catch (Exception ex) {
                                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);

                                }
                            }
                        }

                        if(leitura.alertaArmazemaneto()){
                            String msgAmazenamento = "MEMÓRIA DE ARMAZENAMENTO ACIMA DO ACEITÁVEL!";
                            JOptionPane.showMessageDialog(null,msgAmazenamento);
                            
                            if(slack.getURL() != null){
                                JSONObject message = new JSONObject();
                                message.put("text", msgAmazenamento);
                                try {
                                    slack.insertMessage(message);
                                } catch (Exception ex) {
                                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);

                                }
                            }
                        }

                        if(leitura.alertaCpu()){
                            String msgCpu = "MEMÓRIA PRINCIPAL ACIMA DO ACEITÁVEL!";
                            JOptionPane.showMessageDialog(null, msgCpu);
                            
                            if(slack.getURL() != null){
                                JSONObject message = new JSONObject();
                                message.put("text", msgCpu);
                                try {
                                    slack.insertMessage(message);
                                } catch (Exception ex) {
                                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);

                                }
                            }
                        }

                    }
                }, 200, 3000);
            }
        };

        alertaMemoria.run();

        new Login().setVisible(true);
    }
}
