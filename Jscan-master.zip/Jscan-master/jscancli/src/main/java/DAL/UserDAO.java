package DAL;

import DAL.config.Database;
import Model.Computador;
import Model.Funcionario;
import java.sql.SQLException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class UserDAO implements IDAO<Funcionario> {

    private Database db;
    private JdbcTemplate connection;
    private boolean fristConnection;

    public boolean isFristConnection() {
        return fristConnection;
    }

    public UserDAO() throws SQLException {
        db = new Database();
        connection = db.getConnection();
    }

    @Override
    public boolean Get() throws SQLException {
        //Pegar o user no banco

        if (Funcionario.getNmEmail().equals("") || Funcionario.getNmSenha().equals("")) {
            return false;
        }

        connection.query("SELECT "
                + "IDFUNCIONARIO, NMEMAIL, NMSENHA, IDTIPO "
                + "FROM TB_FUNCIONARIO "
                + "WHERE NMEMAIL = ? "
                + "AND NMSENHA = ?",
                new BeanPropertyRowMapper<Funcionario>(Funcionario.class),
                Funcionario.getNmEmail(),
                Funcionario.getNmSenha()
        //Funcionario.getNmSenha().hashCode());
        );

        //Verificar se o usuário existe no sistema
        if (Funcionario.getIdFuncionario() != 0) {

            if (Funcionario.getIdTipo() == 1) {
                return true; //validação no front por ser mais facil
            }

            //Verificar se existe um computador
            this.getComputer();

            //Caso não, crio e faço a query de select novamente
            if (Computador.getIdComputador() == 0) {
                this.fristConnection = true;
                new OshiInfoDAO().Insert();
                this.getComputer();
            } else {
                this.fristConnection = false;
            }

            return true;
        } else {
            return false;
        }
    }

    @Override
    public void Insert() throws SQLException {
        throw new UnsupportedOperationException("Função não disponível");
    }

    public void CreateSlackLink(String slackLink) throws SQLException {
        connection.update("UPDATE TB_FUNCIONARIO SET SLACK_LINK = ? "
                + " WHERE IDFUNCIONARIO = ?",
                slackLink,
                Funcionario.getIdFuncionario());
    }

    public void getComputer() {
        connection.query("SELECT "
                + "C.IDCOMPUTADOR, "
                + "C.NMCOMPUTADOR, "
                + "C.NMSISTEMAOPERACIONAL, "
                + "C.NMMODELOSISTEMA, "
                + "C.VLMEMORIARAM, "
                + "C.VLARMAZENAMENTO, "
                + "C.NMPROCESSADOR "
                + "FROM TB_COMPUTADOR C "
                + "WHERE IDFUNCIONARIO = ?",
                new BeanPropertyRowMapper<Computador>(Computador.class),
                Funcionario.getIdFuncionario());
    }
}
