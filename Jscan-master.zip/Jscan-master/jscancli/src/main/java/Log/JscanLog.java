package Log;
import java.io.*;
import java.text.*;
import java.util.*;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;

public class JscanLog {
    public String diretorioRaiz = "/Log_Jscan/"; 
    
    public String getDataHora(boolean isTime){
        TimeZone tz = TimeZone.getTimeZone("GMT-3");
         Date now = new Date();
         DateFormat df;
         if(isTime){
             df = new SimpleDateFormat ("yyyy.MM.dd hh:mm:ss ");
         }else{
             df = new SimpleDateFormat ("yyyy.MM.dd");
         }         
         df.setTimeZone(tz);
         String currentTime = df.format(now);
         return currentTime;
    }
    
    public void CriarDiretorioRaiz(){
        File file = new File(diretorioRaiz);
        if (!file.exists()) {
            if (file.mkdir()) {
                System.out.println("Directory is created!");
            } else {
                System.out.println("Failed to create directory!");
            }
        }
    }
    
    public String CriarText(){
        String nome = diretorioRaiz + getDataHora(false) + ".txt";
        File arquivo = new File(nome);
        try {
            if (arquivo.createNewFile())
            {
                System.out.println("Arquivo Criado");
            } else {
                System.out.println("Arquivo já Existe");
            }
        } catch (IOException ex) {
            Logger.getLogger(JscanLog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return nome;
    }
    
    public void gravaLog(String erro) throws IOException {
         CriarDiretorioRaiz();
         String arquivo = CriarText();
         String dataHora = getDataHora(true);     
         FileWriter aWriter = new FileWriter( arquivo, true);
         aWriter.write(dataHora + " " + erro + "\r\n" + "\r\n");
         aWriter.flush();
         aWriter.close();
     }
}
