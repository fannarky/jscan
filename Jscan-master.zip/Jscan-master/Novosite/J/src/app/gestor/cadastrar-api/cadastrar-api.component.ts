import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastrar-api',
  templateUrl: './cadastrar-api.component.html',
  styleUrls: ['./cadastrar-api.component.css']
})
export class CadastrarApiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
