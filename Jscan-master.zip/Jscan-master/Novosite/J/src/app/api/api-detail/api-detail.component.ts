import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-api-detail',
  templateUrl: './api-detail.component.html',
  styleUrls: ['./api-detail.component.scss']
})
export class ApiDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
