import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-api-list-simple',
  templateUrl: './api-list-simple.component.html',
  styleUrls: ['./api-list-simple.component.scss']
})
export class ApiListSimpleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
