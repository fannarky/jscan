import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DesenvolvedorComponent } from './desenvolvedor.component';
import { ApiDetailComponent } from '../api/api-detail/api-detail.component';

const routes: Routes = [
    { 
      path: '', 
      component: DesenvolvedorComponent 
    },
    {
      path: 'api/detalhe/:id',
      component: ApiDetailComponent
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DesenvolvedorRoutingModule { }
