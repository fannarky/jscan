import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalhamento-api',
  templateUrl: './detalhamento-api.component.html',
  styleUrls: ['./detalhamento-api.component.css']
})
export class DetalhamentoApiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
