import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apis-cadastradas',
  templateUrl: './apis-cadastradas.component.html',
  styleUrls: ['./apis-cadastradas.component.css']
})
export class ApisCadastradasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
