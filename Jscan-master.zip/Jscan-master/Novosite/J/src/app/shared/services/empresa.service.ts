import { Injectable } from '@angular/core';
import { LoginService } from './login.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Funcionario } from '../models/funcionario';

@Injectable({
  providedIn: 'root'
})
export class EmpresaService {
  headers_object = new HttpHeaders().set("Authorization", "Bearer " + this.ls.resposta.token);
  //new HttpHeaders({ 'Content-Type': 'application/json'}
  httpOptions = {
    headers: this.headers_object
    
  };
  constructor(private ls: LoginService, private http: HttpClient) { }
  url = environment.urlapi;

  getFuncionariosEmpresa(id: number){
    return this.http.get<Funcionario[]>(this.url + `/company/get/${id}`, this.httpOptions)
  }
}

