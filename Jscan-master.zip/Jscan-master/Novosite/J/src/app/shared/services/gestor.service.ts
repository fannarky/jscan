import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Funcionario } from '../models/funcionario';
import { Api } from '../models/api';
import { PcDados } from '../models/pcdados';
import { Observable } from 'rxjs';
import { LoginService } from './login.service';


@Injectable({
  providedIn: 'root'
})




export class GestorService {
  headers_object = new HttpHeaders().set("Authorization", "Bearer " + this.ls.resposta.token);
  //new HttpHeaders({ 'Content-Type': 'application/json'}
  httpOptions = {
    headers: this.headers_object
    
  };
  constructor(private http: HttpClient, private ls: LoginService) { }
  private url = environment.urlapi + "/users";

  getFuncionarios(id: number): Observable<Funcionario[]> {
    return this.http.get<Funcionario[]>(this.url + `/getlist/${id}`, this.httpOptions)
  } 

  getApis(id: number){
    return this.http.get<Api[]>(this.url + `/api/${id}`);
  } 

  //nao sei oq colocar na model de detalhe 
  // detalheAPI(id){
  //   return this.http.get<ApiDetalhe>(this.url + `/api/${id}`);
  // }

  setAPI(api: Api){
    return this.http.post(this.url + `/api`, api, this.httpOptions);
  }

  setFuncionario(func: Funcionario){
    return this.http.post<Funcionario>(this.url + `/add`, func, this.httpOptions);
  }

  getDadosPc(id){
    return this.http.get<PcDados>(this.url + `/pc/dados/${id}`);
  }

}
