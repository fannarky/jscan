import { Menu } from './menu';

export class Usuario{
  idFuncionario?: number;
  nmFuncionario?: string;
  nmEmail?: string;
  nmSenha?: string;
  idEmpresa?: number;
  idGestor?: number;
  idTipo?: number;
  NRTELEFONE?: string;
  token?: string;
  message?: string;
  menu: Menu[]
}