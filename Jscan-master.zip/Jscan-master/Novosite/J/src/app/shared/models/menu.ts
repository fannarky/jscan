export class Menu {
    path: string;
    titulo: string;
    icone?: String;
}