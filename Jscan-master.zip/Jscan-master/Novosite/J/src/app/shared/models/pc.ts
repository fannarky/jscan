export class Pc{
    name: String;
    namePc: String;
    processador: String;
    memoria: String;
    armazenamento: String;
}