export class Api {
    idapi: number;
    nmApi: string;
    idtipoapi: number;
    ativo: boolean;
}