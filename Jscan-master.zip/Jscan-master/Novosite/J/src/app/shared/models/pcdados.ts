export class PcDados{
    dtregistro: String;
    vlLeituraDisco?: number;
    vlLeituraArmazenamento?: number;
    vlleituraRam?: number;
    vlLeituraCpu?: number; 
}