﻿using System;
using System.Net;

namespace JscanMonitoringCore.Util
{
    /// <summary>
    /// Classe para guardar as validações da API em funcionamento
    /// </summary>
    public static class ValidationMethods
    {
        public static bool IsOnline;

        /// <summary>
        /// Método Responsável por ler o status code da API, e validar se a API está ou não online.
        /// </summary>
        public static void ValidateStatusCode(HttpStatusCode code)
        {
            Console.WriteLine("validando codigo de resposta...");
            IsOnline = code == HttpStatusCode.OK;
        }
    }
}
