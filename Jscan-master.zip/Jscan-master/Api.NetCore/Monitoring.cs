﻿using JscanMonitoringCore.Data.DAO;
using JscanMonitoringCore.Data.Model;
using JscanMonitoringCore.Util;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace JscanMonitoringCore
{
    class Monitoring
    {
        private static ReadDAO _newRead;

        static async Task Main()
        {
            ApiDAO getApis = new ApiDAO();

            var apis = getApis.GetAll();

            Console.WriteLine("Bem vindo! Iniciando monitoramento de APIS...\n by: Jscan\n v1.0.0-ALPHA\n");

            await MonitoringApi(apis);
        }

        static async Task MonitoringApi(IList<Api> apis)
        {
            _newRead = new ReadDAO();
            int minute = 60000;
            HttpResponseMessage response;

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    while (true)
                    {
                        foreach (Api api in apis)
                        {
                            Console.WriteLine("Iniciando monitoramento da API: "+ api.Name);

                            response = await client.GetAsync(api.EndPoint);//Faz a requisição

                            ValidationMethods.ValidateStatusCode(response.StatusCode);//Valida o status code retornado da requisição

                            if (ValidationMethods.IsOnline)
                            {
                                Console.WriteLine("API Online!");
                            }
                            else
                            {
                                Console.WriteLine("API Offline :(");
                            }

                            //Instanciando um novo objeto de leitura
                            Read read = new Read
                            {
                                Active = ValidationMethods.IsOnline,
                                ReadMoment = DateTime.Now,
                                IdApi = api.Id
                            };

                            _newRead.Insert(read);

                            Console.WriteLine("");//Quebra de linha para o próximo monitoramento
                        }
                        Thread.Sleep(minute);
                    }
                }
                catch (HttpRequestException e)
                {
                    //tratamento de exceção
                    Console.WriteLine("\nOcorreu uma exceção!");
                    Console.WriteLine("Mensagem :{0} ", e.Message);
                }
            }
        }
    }
}
